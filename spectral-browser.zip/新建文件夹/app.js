let spectra = [];
let selectedIds = [];
// 传感器波段数据
let sensorBands = {
  landsat8: [],
  sentinel2: []
};

// 存储传感器真实光谱响应函数（SRF）
let sensorSRF = {
    landsat8: null,
    sentinel2: null
};

// 当前选择的传感器
let currentSensor = "none";
let currentBandId = null;

// 获取传感器选择框
const sensorSelect = document.getElementById("sensorSelect");
// ================= 科学解释模块 =================

// 1. 声明一个全局变量用于存储数据
let explanationsData = {};

// 2. 加载 data/band_explanation.json 文件
fetch("./data/band_explanation.json")
    .then(res => {
        if (!res.ok) throw new Error("未找到 band_explanation.json");
        return res.json();
    })
    .then(data => {
        explanationsData = data;
        console.log("科学解释数据加载成功");
    })
    .catch(err => {
        console.warn("加载科学解释失败（请检查文件路径）:", err);
    });

// 3. 定义更新底部卡片的函数
function updateBandExplanation(sensor, bandId) {
    const container = document.getElementById("explanation");
    if (!container) return;

    // 根据传感器（landsat8/sentinel2）和波段（B1-B9等）读取对应的解释
    const explanation = explanationsData?.[sensor]?.[bandId];

    if (explanation) {
        // 如果有数据，渲染科学解释
        container.innerHTML = `<p style="line-height: 1.6; color: #333;">${explanation}</p>`;
    } else {
        // 如果没数据（验收标准4），显示降级提示
        container.innerHTML = `<p style="color: #888;">暂无 ${bandId} 波段的科学解释，请补充 band_explanation.json 文件。</p>`;
    }
}

// 加载 Landsat-8 真实 SRF 数据
fetch("./sensor/srf/landsat8_srf.json")
    .then(response => {
        if (!response.ok) {
            throw new Error("Landsat-8 SRF 数据加载失败");
        }
        return response.json();
    })
    .then(data => {
        sensorSRF.landsat8 = data.bands;
        console.log("Landsat-8 SRF 加载成功：", Object.keys(data.bands));
    })
    .catch(error => {
        console.error("SRF 加载错误：", error);
    });

    // 加载 Sentinel-2A 真实 SRF 数据
fetch("./sentinel2_srf.json")
    .then(response => {
        if (!response.ok) {
            throw new Error("Sentinel-2A SRF 数据加载失败");
        }
        return response.json();
    })
    .then(data => {
        sensorSRF.sentinel2 = {};

    for (const [bandId, points] of Object.entries(data.bands)) {
        sensorSRF.sentinel2[bandId] = {
        wavelength: points.map(point => point[0]),
        response: points.map(point => point[1])
    };
}
        console.log(
            "Sentinel-2A SRF 加载成功：",
            Object.keys(data.bands)
        );
    })
    .catch(error => {
        console.error("Sentinel-2A SRF 加载错误：", error);
    });
    
// 读取 Landsat-8 波段数据
fetch("./sensor/landsat8.json")
  .then(response => {
    if (!response.ok) {
      throw new Error("Landsat-8 数据加载失败");
    }
    return response.json();
  })
  .then(data => {
    sensorBands.landsat8 = data.bands;
    console.log("Landsat-8 波段加载成功:", data.bands.length);
    if (currentSensor === "landsat8") updateChart();
  })
  .catch(error => console.error(error));

// 读取 Sentinel-2 波段数据
fetch("./sensor/sentinel2.json")
  .then(response => {
    if (!response.ok) {
      throw new Error("Sentinel-2 数据加载失败");
    }
    return response.json();
  })
  .then(data => {
    sensorBands.sentinel2 = data.bands;
    console.log("Sentinel-2 波段加载成功:", data.bands.length);
    if (currentSensor === "sentinel2") updateChart();
  })
  .catch(error => console.error(error));

// 监听传感器选择变化
sensorSelect.addEventListener("change", () => {
  currentSensor = sensorSelect.value;
  currentBandId = null;    // 切换传感器时清空高亮
  renderBands();           // ← 新增
  updateChart();
});

function renderBands() {
    const box = document.getElementById("bandList");
    if (!box) return;

    const bands = sensorBands[currentSensor] || [];
    box.innerHTML = "";

    bands.forEach(b => {
        const btn = document.createElement("button");
        btn.className = "band-btn" + (b.id === currentBandId ? " active" : "");
        btn.innerHTML = `<b>${b.id}</b> ${b.name_cn}<br>
                         <small>${b.min}–${b.max} nm</small>`;
                btn.addEventListener("click", () => {
            currentBandId = b.id;
            renderBands();
            updateChart();
            
            // 【修复后】安全地计算中心波长，并直接传入强制ID
            const minWl = parseFloat(b.min);
            const maxWl = parseFloat(b.max);
            const centerWavelength = (minWl + maxWl) / 2;
            
            queryBandByWavelength(centerWavelength, b.id);
        });
        box.appendChild(btn);
    });
}

// 获取网页控件
const searchInput = document.getElementById("searchInput");
const categorySelect = document.getElementById("categorySelect");
const spectrumList = document.getElementById("spectrumList");
const selectedChips = document.getElementById("selectedChips");
const clearBtn = document.getElementById("clearSpectraBtn");

// 加载真实USGS光谱数据
const dataFiles = [
    "./data/vegetation_batch.json",
    "./data/water.json",
    "./data/soil.json",
    "./data/mineral.json",
    "./data/manmade.json"
];

Promise.all(dataFiles.map(f =>
    fetch(f).then(r => {
        if (!r.ok) throw new Error("HTTP " + r.status + " on " + f);
        return r.json();
    })
))
.then(results => {
    spectra = results.flat();
    console.log("成功加载光谱数量:", spectra.length);

    const byCat = spectra.reduce((acc, s) => {
        acc[s.category] = (acc[s.category] || 0) + 1;
        return acc;
    }, {});
    console.log("按类别统计:", byCat);

    renderOptions();
    renderSelectedChips();

            renderOptions();
        renderSelectedChips();

        // 【修改后】默认不选中任何样本，页面一开始是空白的
        selectedIds = [];
        renderSelectedChips();
        updateChart(); // 传入空的选中列表，图表就是空白的

        // 顺便把底部三个卡片的内容也重置一下
        document.getElementById("bandResult").innerHTML = "请点击图中波段查看";
        document.getElementById("explanation").innerHTML = "点击波段后显示解释";
        const info = document.getElementById("sampleInfo");
        if (info) info.innerHTML = "尚未选择";
})
.catch(err => console.error("读取光谱失败:", err));

// 更新选择列表
function renderOptions() {
  const keyword = searchInput.value.trim().toLowerCase();
  const category = categorySelect.value;

  const filtered = spectra.filter(s => {
    const nameMatch =
      (s.name_cn || "").toLowerCase().includes(keyword) ||
      (s.name || "").toLowerCase().includes(keyword);
    const catMatch = category === "all" || s.category === category;
    return nameMatch && catMatch;
  });

  spectrumList.innerHTML = "";

  if (filtered.length === 0) {
    spectrumList.innerHTML = "<div style='color:#888;font-size:13px;padding:6px;'>没有匹配的样本</div>";
    return;
  }

  filtered.forEach(s => {
    const item = document.createElement("label");
    item.className = "spectrum-item";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.value = s.id;
    cb.checked = selectedIds.includes(s.id);
    cb.addEventListener("change", () => toggleSpectrum(s));

    const text = document.createElement("span");
    text.textContent = s.name_cn
      ? s.name_cn + "（" + s.name + "）"
      : s.name;

    item.appendChild(cb);
    item.appendChild(text);
    spectrumList.appendChild(item);
  });
}

function toggleSpectrum(s) {
  const i = selectedIds.indexOf(s.id);
  if (i === -1) selectedIds.push(s.id);
  else selectedIds.splice(i, 1);

  renderSelectedChips();
  showSampleInfo(s);
  updateChart();
}

function renderSelectedChips() {
  selectedChips.innerHTML = "";

  if (selectedIds.length === 0) {
    selectedChips.textContent = "（尚未选择）";
    return;
  }

  selectedIds.forEach(id => {
    const s = spectra.find(x => x.id === id);
    if (!s) return;

    const chip = document.createElement("span");
    chip.className = "chip";

    const label = document.createElement("span");
    label.textContent = s.name_cn || s.name;

    const x = document.createElement("span");
    x.className = "chip-x";
    x.textContent = "×";
    x.onclick = () => {
      const i = selectedIds.indexOf(id);
      if (i !== -1) selectedIds.splice(i, 1);
      renderOptions();
      renderSelectedChips();
      updateChart();
    };

    chip.appendChild(label);
    chip.appendChild(x);
    selectedChips.appendChild(chip);
  });
}

function showSampleInfo(s) {
    const box = document.getElementById("sampleInfo");
    if (!box) return;

    const rows = [
        { label: "名称", value: (s.name_cn ? s.name_cn + " / " : "") + (s.name || "-") },
        { label: "类别", value: s.category || "-" },
        { label: "来源", value: s.source || "-" },
        { label: "Sample ID", value: s.sample_id || "-" },
        { label: "测量方式", value: s.measurement || "-" }
    ];

    box.innerHTML = rows.map(r => `
        <div class="info-row">
            <span class="label">${r.label}：</span>
            <span class="value">${r.value}</span>
        </div>
    `).join("");
}
// 搜索
searchInput.addEventListener("input", renderOptions);

// 类别筛选
categorySelect.addEventListener("change", renderOptions);

// 清空
clearBtn.addEventListener("click", () => {
  selectedIds = [];
  renderOptions();
  renderSelectedChips();
  document.getElementById("bandResult").textContent =
    "请点击图中的传感器波段查看反射率";
  const info = document.getElementById("sampleInfo");
  if (info) info.innerHTML = "";
  updateChart();
});

// 绘制多条光谱
function updateChart() 
{
  const selected = spectra.filter(s =>
    selectedIds.includes(s.id)
  );

  const traces = selected.map(s => ({
    x: s.wavelength,
    y: s.reflectance,
    type: "scatter",
    mode: "lines",
    name: s.name_cn || s.name,
    connectgaps: false
  }));

  // 获取当前传感器的波段
const bands = sensorBands[currentSensor] || [];

// 创建波段半透明背景区域
const shapes = bands.map(band => {
    const isActive = band.id === currentBandId;
    return {
        type: "rect",
        xref: "x",
        yref: "paper",
        x0: band.min,
        x1: band.max,
        y0: 0,
        y1: 1,
        fillcolor: isActive
            ? "rgba(255, 120, 0, 0.35)"
            : "rgba(255, 165, 0, 0.10)",
        line: { width: 0 },
        layer: "below"
    };
});

  Plotly.react("chart", traces, {
   title: "地物光谱曲线",
   shapes: shapes,
    xaxis: {
      title: "波长（nm）"
    },
    yaxis: {
      title: "反射率",
      range: [0, 1]
    },
    hovermode: "x unified",
    showlegend: true
  }, {
    responsive: true
}).then(gd => {
    gd.removeAllListeners("plotly_click");
    gd.on("plotly_click", handleBandClick);

    // 获取绘图区的背景层
    const plotArea = gd.querySelector(".nsewdrag");

    if (plotArea) {
        plotArea.onclick = function(event) {
            // 获取当前横坐标轴
            const xaxis = gd._fullLayout.xaxis;

            // 鼠标相对于绘图区的水平位置
            const rect = plotArea.getBoundingClientRect();
            const pixelX = event.clientX - rect.left;

            // 将像素位置转换为波长
            const wavelength = xaxis.p2d(pixelX);

            // 查询对应波段的反射率
            const bands = sensorBands[currentSensor] || [];
            const band = bands.find(b =>
                wavelength >= b.min && wavelength <= b.max
            );

            if (band) {
                queryBandByWavelength(wavelength);
            }
        };
    }
});
}

// 计算指定波段范围内的平均反射率
function calculateBandReflectance(sample, band) {
    const wavelengths = sample.wavelength;
    const reflectances = sample.reflectance;

    let sum = 0;
    let count = 0;

    for (let i = 0; i < wavelengths.length; i++) {
        const wl = wavelengths[i];
        const rf = reflectances[i];

        if (
            wl >= band.min &&
            wl <= band.max &&
            typeof rf === "number" &&
            Number.isFinite(rf)
        ) {
            sum += rf;
            count++;
        }
    }

    if (count === 0) {
        return null;
    }

    return sum / count;
}


// 梯形积分：支持不等间隔波长采样
function trapezoidalIntegral(wavelengths, values) {
    if (!Array.isArray(wavelengths) ||
        !Array.isArray(values) ||
        wavelengths.length !== values.length ||
        wavelengths.length < 2) {
        return null;
    }

    let integral = 0;

    for (let i = 0; i < wavelengths.length - 1; i++) {
        const x1 = wavelengths[i];
        const x2 = wavelengths[i + 1];
        const y1 = values[i];
        const y2 = values[i + 1];

        if (!Number.isFinite(x1) ||
            !Number.isFinite(x2) ||
            !Number.isFinite(y1) ||
            !Number.isFinite(y2) ||
            x2 <= x1) {
            return null;
        }

        // 梯形面积 = (上底 + 下底) × 宽度 / 2
        integral += (y1 + y2) * (x2 - x1) / 2;
    }

    return integral;
}

// 使用真实 SRF 计算加权波段反射率
function calculateSRFReflectance(sample, bandId) {
    const srf = sensorSRF[currentSensor]?.[bandId];

    if (!srf) return null;

    const wavelengths = sample.wavelength;
    const reflectances = sample.reflectance;

    if (!wavelengths || !reflectances) return null;

    let weightedSum = 0;
    let weightSum = 0;

    // 保存 SRF 积分所需的波长、响应值和加权反射率
const integralWavelengths = [];
const integralResponses = [];
const integralWeightedValues = [];
const validSRFIndices = [];

    // 遍历 SRF 波长采样点
    for (let i = 0; i < srf.wavelength.length; i++) {
        const wl = srf.wavelength[i];
        const response = srf.response[i];

        if (!Number.isFinite(wl) ||
            !Number.isFinite(response) ||
            response <= 0) {
            continue;
        }

        // 查找光谱中包含当前 SRF 波长的相邻采样点
        for (let j = 0; j < wavelengths.length - 1; j++) {
            const x1 = wavelengths[j];
            const x2 = wavelengths[j + 1];
            const y1 = reflectances[j];
            const y2 = reflectances[j + 1];

            if (wl < x1 || wl > x2 ||
                !Number.isFinite(y1) ||
                !Number.isFinite(y2) ||
                x2 <= x1) {
                continue;
            }

            // 线性插值，得到当前波长的反射率
            const ratio = (wl - x1) / (x2 - x1);
            const reflectance = y1 + ratio * (y2 - y1);

            weightedSum += reflectance * response;
            weightSum += response;
            // 保存当前有效的 SRF 采样数据
            integralWavelengths.push(wl);
            integralResponses.push(response);
            integralWeightedValues.push(reflectance * response);
            validSRFIndices.push(i);

            break;
        }
    }

if (weightSum === 0) return null;

// 计算完整 SRF 的总响应权重
const totalWeight = srf.response.reduce((sum, response) => {
    return sum + (
        Number.isFinite(response) && response > 0
            ? response
            : 0
    );
}, 0);

// 计算有效覆盖率
const coverage = totalWeight > 0
    ? (weightSum / totalWeight) * 100
    : 0;

console.log(
    "SRF覆盖率：",
    bandId,
    coverage.toFixed(2) + "%"
);
// SRF 有效覆盖率低于 95% 时，不输出反射率
if (coverage < 95) {
    console.warn(
        `波段 ${bandId} 的 SRF 覆盖率仅为 ${coverage.toFixed(2)}%，数据不足`
    );
    return null;
}

// 只对原始 SRF 中相邻且有效的采样点进行梯形积分
let numeratorIntegral = 0;
let denominatorIntegral = 0;

for (let k = 0; k < validSRFIndices.length - 1; k++) {
    // 跳过原始 SRF 中不连续的采样点
    if (validSRFIndices[k + 1] !== validSRFIndices[k] + 1) {
        continue;
    }

    const deltaWavelength =
        integralWavelengths[k + 1] - integralWavelengths[k];

    if (deltaWavelength <= 0) {
        continue;
    }

    numeratorIntegral +=
        (integralWeightedValues[k] +
         integralWeightedValues[k + 1]) *
        deltaWavelength / 2;

    denominatorIntegral +=
        (integralResponses[k] +
         integralResponses[k + 1]) *
        deltaWavelength / 2;
}
// 计算完整 SRF 的积分面积
const totalSRFIntegral = trapezoidalIntegral(
    srf.wavelength,
    srf.response
);

// 计算有效积分覆盖率
const integralCoverage =
    totalSRFIntegral !== null && totalSRFIntegral > 0
        ? (denominatorIntegral / totalSRFIntegral) * 100
        : 0;

console.log(
    "SRF积分覆盖率：",
    bandId,
    integralCoverage.toFixed(2) + "%"
);

// 积分覆盖率不足时，不使用梯形积分结果
if (integralCoverage < 95) {
    console.warn(
        `波段 ${bandId} 的 SRF 积分覆盖率仅为 ${integralCoverage.toFixed(2)}%，数据不足`
    );
    return null;
}

// SRF 有效积分覆盖率低于 95% 时，不输出反射率
const trapezoidalResult = denominatorIntegral > 0
    ? numeratorIntegral / denominatorIntegral
    : null;

console.log("梯形积分计算验证：", {
    波段: bandId,
    原加权结果: weightedSum / weightSum,
    梯形积分结果: trapezoidalResult
});
return trapezoidalResult;
}

// 点击光谱图，查询对应波段反射率
function handleBandClick(event) {
    const wavelength = event.points[0].x;
    queryBandByWavelength(wavelength);
}

// 点击光谱图或波段按钮，查询对应波段反射率
function queryBandByWavelength(wavelength, forcedBandId = null) {
    const bands = sensorBands[currentSensor] || [];
    
    // 修复1：优先根据 bandId 精确查找，或者强制转成数字比较
    let band;
    if (forcedBandId) {
        band = bands.find(b => b.id === forcedBandId);
    } else {
        band = bands.find(b => 
            Number(wavelength) >= Number(b.min) && 
            Number(wavelength) <= Number(b.max)
        );
    }

    if (!band) {
        document.getElementById("bandResult").innerHTML =
            "<p>当前点击位置不在传感器波段范围内</p>";
        return;
    }

    // ...（下面代码保持你原来的不变，从 const selected = spectra.filter(... 开始）

    const selected = spectra.filter(s =>
        selectedIds.includes(s.id)
    );

    // 判断当前传感器和波段是否有 SRF 数据
    const srfTable = sensorSRF[currentSensor];
    const hasSRF = srfTable && srfTable[band.id];

    // 1. 构建表格头部信息
    let tableHTML = `
        <div style="margin-bottom:10px; font-size:13px; color:#555; line-height:1.6;">
            <b>波段：${band.id}（${band.name_cn}）</b><br>
            波长范围：${band.min}～${band.max} nm<br>
            计算方法：${hasSRF ? "SRF 光谱响应加权" : "波段内简单平均"}
        </div>
        <table class="reflectance-table">
            <thead>
                <tr>
                    <th>样本名称</th>
                    <th>反射率</th>
                </tr>
            </thead>
            <tbody>
    `;

    // 2. 遍历已选样本，计算反射率并生成表格行
    selected.forEach(sample => {
        const reflectance = hasSRF
            ? calculateSRFReflectance(sample, band.id)
            : calculateBandReflectance(sample, band);

        tableHTML += `
            <tr>
                <td>${sample.name_cn || sample.name}</td>
                <td>${reflectance === null ? "无有效数据" : reflectance.toFixed(4)}</td>
            </tr>
        `;
    });

    tableHTML += `</tbody></table>`;

    // 3. 将表格渲染到页面（注意这里是 innerHTML，不是 textContent）
    document.getElementById("bandResult").innerHTML = tableHTML;

    // 4. 更新底部的“为什么选择这个波段”卡片
    if (typeof updateBandExplanation === "function") {
        updateBandExplanation(currentSensor, band.id);
    }
}

// 模态框控制
const openAboutBtn = document.getElementById("openAboutBtn");
const closeAboutBtn = document.getElementById("closeAboutBtn");
const aboutModal = document.getElementById("aboutModal");

if (openAboutBtn && aboutModal) {
    openAboutBtn.addEventListener("click", () => {
        aboutModal.classList.add("active");
    });
}
if (closeAboutBtn && aboutModal) {
    closeAboutBtn.addEventListener("click", () => {
        aboutModal.classList.remove("active");
    });
}
// 点击遮罩层也可以关闭
if (aboutModal) {
    aboutModal.addEventListener("click", (e) => {
        if (e.target === aboutModal) {
            aboutModal.classList.remove("active");
        }
    });
}